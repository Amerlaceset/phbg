<!DOCTYPE html>
<html>
        <head>
                <title>All</title>
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
        </head>
        <body style="background-color:#ff792c;">
                <h2 style="text-align:center;">The most powerful free events in the application</h2>
                <br></br>

                <p style="text-align:center;"><a href = "pubg2/index.php"><button type="button" class="btn btn-primary btn-lg"> -PUBG MOBILE- </button></a></p>
                <br></br>

                <p style="text-align:center;"><a href = "freefire/index.html"><button type="button" class="btn btn-primary btn-lg"> ---FREE FIRE--- </button></a></p>
                <br></br>

        </body>
</html>
