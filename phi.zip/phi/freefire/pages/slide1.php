<div class="card-wrap">
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/1.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/2.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/3.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/4.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/5.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/6.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/7.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/8.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/9.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/10.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/11.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/senjata/12.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
</div>