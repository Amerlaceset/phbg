<div class="card-wrap">
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/1.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/2.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/3.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/4.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/5.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/6.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/7.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/diamond/8.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
</div>