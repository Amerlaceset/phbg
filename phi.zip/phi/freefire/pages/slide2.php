<div class="card-wrap">
    <div class="card">
        <div class="imgBox">
            <img src="img/old/1.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/2.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/3.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/4.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/5.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/6.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/7.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/8.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/9.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/10.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/11.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/12.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/13.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/14.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/15.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/16.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/old/17.png">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
</div>