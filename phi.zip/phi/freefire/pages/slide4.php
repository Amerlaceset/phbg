<div class="card-wrap">
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/1.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/2.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/3.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/4.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/5.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/6.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/7.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/8.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/9.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/10.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/11.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
    <div class="card">
        <div class="imgBox">
            <img src="img/incubator/12.jpeg">
        </div>
        <div class="btn-claim" onclick="gass(this)">Claim</div>
    </div>
</div>